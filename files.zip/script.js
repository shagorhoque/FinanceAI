// DOM Elements
const chatArea = document.getElementById('chatArea');
const welcomeScreen = document.getElementById('welcomeScreen');
const messagesContainer = document.getElementById('messagesContainer');
const messageInput = document.getElementById('messageInput');
const sendBtn = document.getElementById('sendBtn');
const suggestionBtns = document.querySelectorAll('.suggestion-btn');

// Placeholder AI Responses
const aiResponses = {
    "How should I start investing with $500?": `Great question! Starting with $500 is a smart first step. Here are some options to consider:

**1. Index Funds or ETFs** - These offer instant diversification at low cost. Look for funds tracking the S&P 500 or total market indexes.

**2. Robo-Advisors** - Platforms like Betterment or Wealthfront can manage your money automatically with low minimums.

**3. Individual Stocks** - If you're comfortable with more risk, you could buy fractional shares of companies you believe in.

**4. High-Yield Savings First** - Make sure you have an emergency fund before investing!

The key is to start early and invest consistently. Would you like more details on any of these options?`,

    "What's the 50/30/20 budget rule?": `The 50/30/20 rule is a simple budgeting framework that divides your after-tax income into three categories:

**50% for Needs** - Essential expenses like rent/mortgage, utilities, groceries, insurance, minimum debt payments, and transportation.

**30% for Wants** - Non-essential spending like dining out, entertainment, hobbies, subscriptions, and shopping.

**20% for Savings & Debt** - Emergency fund, retirement contributions, extra debt payments, and other savings goals.

For example, if you earn $4,000/month after taxes:
• $2,000 goes to needs
• $1,200 goes to wants  
• $800 goes to savings

It's a flexible starting point—adjust based on your situation and goals!`,

    "How much should I save for retirement?": `A common guideline is to save **10-15% of your gross income** for retirement, but the ideal amount depends on several factors:

**Age matters:**
• Starting in your 20s: 10-15% may be enough
• Starting in your 30s: Aim for 15-20%
• Starting later: You may need 20-25% or more

**Consider these milestones:**
• By 30: Have 1x your annual salary saved
• By 40: Have 3x your salary
• By 50: Have 6x your salary
• By 60: Have 8x your salary

**Don't forget employer matches!** If your employer offers a 401(k) match, contribute at least enough to get the full match—it's free money.

Would you like help calculating a specific savings target based on your situation?`,

    "default": `That's a thoughtful question about personal finance! While I'd need more specific details to give you personalized advice, here are some general principles:

**Key financial foundations:**
1. Build an emergency fund (3-6 months of expenses)
2. Pay off high-interest debt
3. Take advantage of employer retirement matches
4. Diversify your investments

Remember, everyone's financial situation is unique. Consider consulting with a certified financial planner for personalized guidance.

Is there a specific aspect of this topic you'd like me to explore further?`
};

// State
let isTyping = false;

// Initialize
function init() {
    // Event Listeners
    sendBtn.addEventListener('click', handleSend);
    messageInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            handleSend();
        }
    });

    suggestionBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            const message = btn.dataset.message;
            sendMessage(message);
        });
    });
}

// Handle Send Button Click
function handleSend() {
    const message = messageInput.value.trim();
    if (message && !isTyping) {
        sendMessage(message);
    }
}

// Send Message
function sendMessage(message) {
    // Hide welcome screen
    welcomeScreen.classList.add('hidden');
    
    // Clear input
    messageInput.value = '';
    
    // Add user message
    addMessage(message, 'user');
    
    // Show typing indicator and get AI response
    isTyping = true;
    showTypingIndicator();
    
    // Simulate AI response delay
    const delay = 1000 + Math.random() * 1500;
    setTimeout(() => {
        hideTypingIndicator();
        const response = getAIResponse(message);
        addMessage(response, 'ai');
        isTyping = false;
    }, delay);
}

// Add Message to Chat
function addMessage(content, type) {
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${type}`;
    
    const avatarSvg = type === 'user' 
        ? `<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M20 21V19C20 17.9391 19.5786 16.9217 18.8284 16.1716C18.0783 15.4214 17.0609 15 16 15H8C6.93913 15 5.92172 15.4214 5.17157 16.1716C4.42143 16.9217 4 17.9391 4 19V21" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <circle cx="12" cy="7" r="4" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
           </svg>`
        : `<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M12 2L13.09 8.26L18 6L14.74 10.91L21 12L14.74 13.09L18 18L13.09 15.74L12 22L10.91 15.74L6 18L9.26 13.09L3 12L9.26 10.91L6 6L10.91 8.26L12 2Z" fill="white"/>
           </svg>`;
    
    // Format content with markdown-like styling
    const formattedContent = formatMessage(content);
    
    messageDiv.innerHTML = `
        <div class="message-avatar">
            ${avatarSvg}
        </div>
        <div class="message-content">
            ${formattedContent}
        </div>
    `;
    
    messagesContainer.appendChild(messageDiv);
    scrollToBottom();
}

// Format Message Content
function formatMessage(content) {
    // Convert **text** to bold
    let formatted = content.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
    
    // Convert line breaks to <br>
    formatted = formatted.replace(/\n/g, '<br>');
    
    return formatted;
}

// Show Typing Indicator
function showTypingIndicator() {
    const typingDiv = document.createElement('div');
    typingDiv.className = 'message ai';
    typingDiv.id = 'typingIndicator';
    
    typingDiv.innerHTML = `
        <div class="message-avatar">
            <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M12 2L13.09 8.26L18 6L14.74 10.91L21 12L14.74 13.09L18 18L13.09 15.74L12 22L10.91 15.74L6 18L9.26 13.09L3 12L9.26 10.91L6 6L10.91 8.26L12 2Z" fill="white"/>
            </svg>
        </div>
        <div class="message-content">
            <div class="typing-indicator">
                <span></span>
                <span></span>
                <span></span>
            </div>
        </div>
    `;
    
    messagesContainer.appendChild(typingDiv);
    scrollToBottom();
}

// Hide Typing Indicator
function hideTypingIndicator() {
    const typingIndicator = document.getElementById('typingIndicator');
    if (typingIndicator) {
        typingIndicator.remove();
    }
}

// Get AI Response
function getAIResponse(message) {
    // Check for exact matches first
    if (aiResponses[message]) {
        return aiResponses[message];
    }
    
    // Check for keyword matches
    const lowerMessage = message.toLowerCase();
    
    if (lowerMessage.includes('invest') && (lowerMessage.includes('500') || lowerMessage.includes('start'))) {
        return aiResponses["How should I start investing with $500?"];
    }
    
    if (lowerMessage.includes('50/30/20') || lowerMessage.includes('50 30 20') || 
        (lowerMessage.includes('budget') && lowerMessage.includes('rule'))) {
        return aiResponses["What's the 50/30/20 budget rule?"];
    }
    
    if (lowerMessage.includes('retirement') && lowerMessage.includes('save')) {
        return aiResponses["How much should I save for retirement?"];
    }
    
    // Return default response for other queries
    return aiResponses["default"];
}

// Scroll to Bottom of Chat
function scrollToBottom() {
    chatArea.scrollTop = chatArea.scrollHeight;
}

// Initialize on DOM Load
document.addEventListener('DOMContentLoaded', init);
